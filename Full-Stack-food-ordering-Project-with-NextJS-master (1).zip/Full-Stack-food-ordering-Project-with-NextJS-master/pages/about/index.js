import React from "react";
import About from "../../components/About";

const Index = () => {
  return (
    <div>
      <About />
    </div>
  );
};

export default Index;
